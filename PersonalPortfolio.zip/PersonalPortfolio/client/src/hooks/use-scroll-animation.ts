import { useEffect, useRef } from 'react';

export const useScrollAnimation = () => {
  const observerRef = useRef<IntersectionObserver | null>(null);

  useEffect(() => {
    const observerOptions = {
      threshold: 0.1,
      rootMargin: '0px 0px -50px 0px'
    };

    observerRef.current = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.remove('section-hidden');
          entry.target.classList.add('section-visible');
          
          // Animate skill bars
          const skillBars = entry.target.querySelectorAll('.skill-progress');
          skillBars.forEach((bar) => {
            const htmlBar = bar as HTMLElement;
            setTimeout(() => {
              const skillWidth = htmlBar.style.getPropertyValue('--skill-width');
              htmlBar.style.width = skillWidth;
            }, 500);
          });
        }
      });
    }, observerOptions);

    // Observe all sections
    document.querySelectorAll('.section-hidden').forEach(section => {
      observerRef.current?.observe(section);
    });

    return () => {
      observerRef.current?.disconnect();
    };
  }, []);

  return observerRef;
};
