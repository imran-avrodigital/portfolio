import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Menu, X } from 'lucide-react';

const Navigation = () => {
  const [activeSection, setActiveSection] = useState('home');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      const sections = document.querySelectorAll('section');
      const navLinks = document.querySelectorAll('nav a[href^="#"]');
      
      let current = '';
      sections.forEach(section => {
        const sectionTop = section.offsetTop;
        if (window.scrollY >= (sectionTop - 200)) {
          current = section.getAttribute('id') || '';
        }
      });

      setActiveSection(current);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleClick = (e: React.MouseEvent<HTMLAnchorElement>, targetId: string) => {
    e.preventDefault();
    const target = document.querySelector(targetId);
    if (target) {
      target.scrollIntoView({
        behavior: 'smooth',
        block: 'start'
      });
    }
    // Close mobile menu after clicking
    setIsMobileMenuOpen(false);
  };

  const navItems = [
    { id: 'home', label: 'Home', color: 'blue' },
    { id: 'about', label: 'About', color: 'cyan' },
    { id: 'projects', label: 'Projects', color: 'purple' },
    { id: 'services', label: 'Services', color: 'green' },
    { id: 'testimonials', label: 'Testimonials', color: 'yellow' },
    { id: 'contact', label: 'Contact', color: 'pink' }
  ];

  const getColorClasses = (color: string, isActive: boolean) => {
    const colorMap = {
      blue: isActive ? 'text-blue-400' : 'text-gray-300 hover:text-blue-400',
      cyan: isActive ? 'text-cyan-400' : 'text-gray-300 hover:text-cyan-400',
      purple: isActive ? 'text-purple-400' : 'text-gray-300 hover:text-purple-400',
      green: isActive ? 'text-green-400' : 'text-gray-300 hover:text-green-400',
      yellow: isActive ? 'text-yellow-400' : 'text-gray-300 hover:text-yellow-400',
      pink: isActive ? 'text-pink-400' : 'text-gray-300 hover:text-pink-400'
    };
    return colorMap[color as keyof typeof colorMap] || 'text-gray-300';
  };

  const getIndicatorColor = (color: string) => {
    const colorMap = {
      blue: 'bg-blue-400',
      cyan: 'bg-cyan-400',
      purple: 'bg-purple-400',
      green: 'bg-green-400',
      yellow: 'bg-yellow-400',
      pink: 'bg-pink-400'
    };
    return colorMap[color as keyof typeof colorMap] || 'bg-blue-400';
  };

  return (
    <motion.nav 
      initial={{ y: -100, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.8 }}
      className="fixed top-0 left-0 right-0 z-50 bg-black/90 backdrop-blur-sm border-b border-gray-800"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center py-4">
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-xl font-bold gradient-text"
          >
            Imran Nazir
          </motion.div>
          
          <div className="hidden md:flex space-x-8">
            {navItems.map((item, index) => (
              <motion.a
                key={item.id}
                href={`#${item.id}`}
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.1 * index }}
                onClick={(e) => handleClick(e, `#${item.id}`)}
                className={`nav-item relative group px-3 py-2 transition-colors ${getColorClasses(item.color, activeSection === item.id)}`}
              >
                <span className={`nav-indicator absolute left-0 top-0 bottom-0 w-1 ${getIndicatorColor(item.color)}`} />
                {item.label}
              </motion.a>
            ))}
          </div>
          
          <div className="md:hidden">
            <motion.button
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="p-2 text-gray-300 hover:text-blue-400 transition-colors"
            >
              {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </motion.button>
          </div>
        </div>
      </div>
      
      {/* Mobile Menu Overlay */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.3 }}
            className="md:hidden absolute top-full left-0 right-0 bg-black/95 backdrop-blur-sm border-b border-gray-800"
          >
            <div className="max-w-7xl mx-auto px-4 py-4">
              <div className="flex flex-col space-y-4">
                {navItems.map((item, index) => (
                  <motion.a
                    key={item.id}
                    href={`#${item.id}`}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    transition={{ duration: 0.3, delay: 0.1 * index }}
                    onClick={(e) => handleClick(e, `#${item.id}`)}
                    className={`nav-item relative group px-4 py-3 rounded-lg text-lg transition-all duration-300 ${getColorClasses(item.color, activeSection === item.id)} hover:bg-gray-800/50`}
                  >
                    <div className="flex items-center space-x-3">
                      <span className={`w-2 h-2 rounded-full ${getIndicatorColor(item.color)}`} />
                      <span>{item.label}</span>
                    </div>
                  </motion.a>
                ))}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.nav>
  );
};

export default Navigation;
