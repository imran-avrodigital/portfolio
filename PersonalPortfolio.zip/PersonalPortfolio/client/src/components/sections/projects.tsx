import { motion } from 'framer-motion';
import { useScrollAnimation } from '@/hooks/use-scroll-animation';

const Projects = () => {
  useScrollAnimation();

  const projects = [
    {
      title: 'Avrodigital.co',
      role: 'Digital Marketing Lead & SEO Strategist',
      roleColor: 'text-emerald-400',
      borderColor: 'hover:border-emerald-500',
      icon: 'fas fa-rocket',
      iconBg: 'from-emerald-500 to-green-500',
      description: 'Leading comprehensive digital marketing campaigns, SEO strategy implementation, and team coordination across multiple client projects.',
      result: 'Multi-Client Success',
      resultSubtext: 'Ongoing Leadership',
      resultBg: 'from-emerald-500/20 to-green-500/20',
      resultBorder: 'border-emerald-500/30',
      resultColor: 'text-emerald-400'
    },
    {
      title: 'Phototovector.com',
      role: 'Project Manager & SEO Lead',
      roleColor: 'text-cyan-400',
      borderColor: 'hover:border-cyan-500',
      icon: 'fas fa-image',
      iconBg: 'from-cyan-500 to-teal-500',
      description: 'Ongoing project focusing on SEO planning, blog content direction, and comprehensive backlink strategy development.',
      result: 'Month 2 KPIs',
      resultSubtext: 'In Progress',
      resultBg: 'from-cyan-500/20 to-teal-500/20',
      resultBorder: 'border-cyan-500/30',
      resultColor: 'text-cyan-400'
    },
    {
      title: 'BuyBigInflatableThings.com',
      role: 'SEO Strategist & Project Manager',
      roleColor: 'text-blue-400',
      borderColor: 'hover:border-blue-500',
      icon: 'fas fa-chart-bar',
      iconBg: 'from-blue-500 to-cyan-500',
      description: 'Full-site SEO, content planning, technical optimization, and comprehensive blog strategy implementation.',
      result: '+260% Organic Traffic',
      resultSubtext: 'in 4 months',
      resultBg: 'from-green-500/20 to-blue-500/20',
      resultBorder: 'border-green-500/30',
      resultColor: 'text-green-400'
    },
    {
      title: 'Bestwheeled.com',
      role: 'SEO Specialist & Content Strategist',
      roleColor: 'text-orange-400',
      borderColor: 'hover:border-orange-500',
      icon: 'fas fa-bicycle',
      iconBg: 'from-orange-500 to-red-500',
      description: 'Comprehensive SEO audit, content optimization, and link building strategy for automotive and mobility sector.',
      result: 'Top 3 Rankings',
      resultSubtext: 'for competitive keywords',
      resultBg: 'from-orange-500/20 to-red-500/20',
      resultBorder: 'border-orange-500/30',
      resultColor: 'text-orange-400'
    },
    {
      title: 'DigitalDivingBoard.com',
      role: 'Technical SEO & WordPress Developer',
      roleColor: 'text-indigo-400',
      borderColor: 'hover:border-indigo-500',
      icon: 'fas fa-diving',
      iconBg: 'from-indigo-500 to-blue-500',
      description: 'Technical SEO implementation, WordPress optimization, and performance enhancement for digital services platform.',
      result: 'Performance Boost',
      resultSubtext: '3x faster loading',
      resultBg: 'from-indigo-500/20 to-blue-500/20',
      resultBorder: 'border-indigo-500/30',
      resultColor: 'text-indigo-400'
    },
    {
      title: 'ElectricScooter.com',
      role: 'Content Writer & WordPress Developer',
      roleColor: 'text-purple-400',
      borderColor: 'hover:border-purple-500',
      icon: 'fas fa-bolt',
      iconBg: 'from-purple-500 to-pink-500',
      description: 'Built high-converting landing pages, conducted extensive keyword research, and implemented on-page SEO optimizations.',
      result: '#1 Rankings',
      resultSubtext: 'for 7+ long-tail keywords',
      resultBg: 'from-purple-500/20 to-pink-500/20',
      resultBorder: 'border-purple-500/30',
      resultColor: 'text-purple-400'
    }
  ];

  return (
    <section id="projects" className="py-20 bg-gray-950/50">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="section-hidden">
          <motion.h2 
            className="text-4xl md:text-5xl font-bold text-center mb-16 gradient-text"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            Featured Projects
          </motion.h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
            {projects.map((project, index) => (
              <motion.div
                key={index}
                className={`project-card bg-gray-900 rounded-xl p-6 border border-gray-800 ${project.borderColor} cursor-pointer`}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.2 }}
                viewport={{ once: true }}
                whileHover={{ 
                  y: -8, 
                  scale: 1.02,
                  boxShadow: '0 20px 40px rgba(59, 130, 246, 0.2)'
                }}
              >
                <div className="mb-4">
                  <motion.div 
                    className={`w-12 h-12 bg-gradient-to-r ${project.iconBg} rounded-lg flex items-center justify-center mb-4`}
                    whileHover={{ rotate: 360, scale: 1.1 }}
                    transition={{ duration: 0.5 }}
                  >
                    <i className={`${project.icon} text-white text-xl`}></i>
                  </motion.div>
                  <h3 className="text-xl font-bold text-white mb-2">{project.title}</h3>
                  <p className={`${project.roleColor} text-sm font-medium mb-3`}>{project.role}</p>
                </div>
                
                <div className="space-y-3 mb-6">
                  <p className="text-gray-300 text-sm">{project.description}</p>
                </div>
                
                <motion.div 
                  className="project-result opacity-70 hover:opacity-100 transition-opacity"
                  whileHover={{ scale: 1.05 }}
                >
                  <div className={`bg-gradient-to-r ${project.resultBg} rounded-lg p-3 border ${project.resultBorder}`}>
                    <div className={`${project.resultColor} font-bold text-lg`}>{project.result}</div>
                    <div className="text-gray-400 text-sm">{project.resultSubtext}</div>
                  </div>
                </motion.div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Projects;
