import { motion } from 'framer-motion';
import { useScrollAnimation } from '@/hooks/use-scroll-animation';

const Services = () => {
  useScrollAnimation();

  const services = [
    {
      title: 'SEO Strategy & Keyword Research',
      description: 'Comprehensive SEO planning and keyword analysis',
      icon: 'fas fa-search',
      bgColor: 'bg-blue-500',
      hoverColor: 'hover:border-blue-500'
    },
    {
      title: 'Off-Page SEO & Link Building',
      description: 'Strategic backlink acquisition and authority building',
      icon: 'fas fa-link',
      bgColor: 'bg-emerald-500',
      hoverColor: 'hover:border-emerald-500'
    },
    {
      title: 'WordPress Design & Development',
      description: 'Custom WordPress solutions and optimization',
      icon: 'fab fa-wordpress',
      bgColor: 'bg-purple-500',
      hoverColor: 'hover:border-purple-500'
    },
    {
      title: 'Content Writing & Blog Strategy',
      description: 'Strategic content creation and planning',
      icon: 'fas fa-pen',
      bgColor: 'bg-cyan-500',
      hoverColor: 'hover:border-cyan-500'
    },
    {
      title: 'Technical & On-Page SEO',
      description: 'Technical optimization and on-page improvements',
      icon: 'fas fa-cog',
      bgColor: 'bg-green-500',
      hoverColor: 'hover:border-green-500'
    },
    {
      title: 'Social Media Marketing',
      description: 'Social media strategy and campaign management',
      icon: 'fas fa-share-alt',
      bgColor: 'bg-pink-500',
      hoverColor: 'hover:border-pink-500'
    }
  ];

  const skills = [
    {
      name: 'SEO & Analytics',
      percentage: 95,
      tools: ['SEMrush', 'Google Analytics', 'GSC'],
      gradient: 'from-blue-500 to-cyan-500',
      toolBg: 'bg-blue-500/20',
      toolColor: 'text-blue-400'
    },
    {
      name: 'WordPress Development',
      percentage: 90,
      tools: ['WordPress', 'Elementor', 'Rank Math'],
      gradient: 'from-purple-500 to-pink-500',
      toolBg: 'bg-purple-500/20',
      toolColor: 'text-purple-400'
    },
    {
      name: 'Video Editing',
      percentage: 88,
      tools: ['Adobe Premiere Pro', 'CapCut', 'Post-Production'],
      gradient: 'from-red-500 to-pink-500',
      toolBg: 'bg-red-500/20',
      toolColor: 'text-red-400'
    },
    {
      name: 'AI Content Creation',
      percentage: 92,
      tools: ['Kling AI', 'Runway ML', 'Google VEO'],
      gradient: 'from-violet-500 to-purple-500',
      toolBg: 'bg-violet-500/20',
      toolColor: 'text-violet-400'
    },
    {
      name: 'AI & Creative Tools',
      percentage: 85,
      tools: ['ChatGPT', 'Canva', 'MidJourney'],
      gradient: 'from-green-500 to-teal-500',
      toolBg: 'bg-green-500/20',
      toolColor: 'text-green-400'
    },
    {
      name: 'Social Media Marketing',
      percentage: 90,
      tools: ['Facebook Organic', 'Instagram Marketing', 'Content Strategy'],
      gradient: 'from-pink-500 to-rose-500',
      toolBg: 'bg-pink-500/20',
      toolColor: 'text-pink-400'
    },
    {
      name: 'Digital Marketing',
      percentage: 88,
      tools: ['Facebook Ads', 'Mailchimp', 'PPC Campaigns'],
      gradient: 'from-yellow-500 to-orange-500',
      toolBg: 'bg-yellow-500/20',
      toolColor: 'text-yellow-400'
    }
  ];

  return (
    <section id="services" className="py-20">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="section-hidden">
          <motion.h2 
            className="text-4xl md:text-5xl font-bold text-center mb-16 gradient-text"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            Services & Skills
          </motion.h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12">
            {/* What I Do */}
            <motion.div 
              className="animate-fadeInLeft"
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              viewport={{ once: true }}
            >
              <h3 className="text-2xl font-bold text-blue-400 mb-8 flex items-center">
                <i className="fas fa-check-circle mr-3"></i>
                What I Do
              </h3>
              <div className="space-y-6">
                {services.map((service, index) => (
                  <motion.div
                    key={index}
                    className={`flex items-start space-x-4 p-4 bg-gray-900/50 rounded-lg border border-gray-800 ${service.hoverColor} transition-colors cursor-pointer`}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.6, delay: 0.4 + index * 0.1 }}
                    viewport={{ once: true }}
                    whileHover={{ scale: 1.02, x: 10 }}
                  >
                    <motion.div 
                      className={`w-8 h-8 ${service.bgColor} rounded-lg flex items-center justify-center flex-shrink-0`}
                      whileHover={{ rotate: 360 }}
                      transition={{ duration: 0.5 }}
                    >
                      <i className={`${service.icon} text-white text-sm`}></i>
                    </motion.div>
                    <div>
                      <h4 className="font-semibold text-white">{service.title}</h4>
                      <p className="text-gray-400 text-sm mt-1">{service.description}</p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.div>

            {/* Tools & Skills */}
            <motion.div 
              className="animate-fadeInRight"
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.4 }}
              viewport={{ once: true }}
            >
              <h3 className="text-2xl font-bold text-purple-400 mb-8 flex items-center">
                <i className="fas fa-tools mr-3"></i>
                Tools & Expertise
              </h3>
              <div className="space-y-4">
                {skills.map((skill, index) => (
                  <motion.div
                    key={index}
                    className="skill-item"
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.6, delay: 0.6 + index * 0.2 }}
                    viewport={{ once: true }}
                  >
                    <div className="flex justify-between mb-2">
                      <span className="text-white font-medium">{skill.name}</span>
                      <span className="text-gray-400">{skill.percentage}%</span>
                    </div>
                    <div className="skill-bar w-full bg-gray-800 rounded-full h-2 mb-2">
                      <motion.div 
                        className={`skill-progress bg-gradient-to-r ${skill.gradient} h-full rounded-full`}
                        style={{ '--skill-width': `${skill.percentage}%` } as React.CSSProperties}
                        initial={{ width: '0%' }}
                        whileInView={{ width: `${skill.percentage}%` }}
                        transition={{ duration: 2, delay: 0.8 + index * 0.2 }}
                        viewport={{ once: true }}
                      />
                    </div>
                    <div className="flex flex-wrap gap-2 mt-2">
                      {skill.tools.map((tool, toolIndex) => (
                        <motion.span
                          key={toolIndex}
                          className={`text-xs ${skill.toolBg} ${skill.toolColor} px-2 py-1 rounded cursor-pointer`}
                          initial={{ opacity: 0, scale: 0 }}
                          whileInView={{ opacity: 1, scale: 1 }}
                          transition={{ duration: 0.4, delay: 1.0 + index * 0.2 + toolIndex * 0.1 }}
                          viewport={{ once: true }}
                          whileHover={{ scale: 1.1, y: -2 }}
                        >
                          {tool}
                        </motion.span>
                      ))}
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Services;
