import { motion } from 'framer-motion';
import { useScrollAnimation } from '@/hooks/use-scroll-animation';

const Testimonials = () => {
  useScrollAnimation();

  const testimonials = [
    {
      name: 'Arafat Rahman',
      title: 'CEO, Avro Digital',
      rating: 5,
      text: 'Imran is one of the sharpest digital marketers I\'ve worked with. From SEO to full campaign strategy, he delivers results.',
      avatar: 'fas fa-user-tie',
      bgColor: 'bg-blue-500',
      borderColor: 'hover:border-blue-500'
    },
    {
      name: 'Sarah M.',
      title: 'Marketing Director',
      rating: 5,
      text: 'Outstanding SEO work! Our organic traffic increased by 260% in just 4 months. Imran\'s strategic approach is impressive.',
      avatar: 'fas fa-user-circle',
      bgColor: 'bg-purple-500',
      borderColor: 'hover:border-purple-500'
    },
    {
      name: 'David K.',
      title: 'E-commerce Owner',
      rating: 5,
      text: 'Professional, reliable, and results-driven. Imran transformed our WordPress site and helped us rank #1 for key terms.',
      avatar: 'fas fa-user',
      bgColor: 'bg-green-500',
      borderColor: 'hover:border-green-500'
    }
  ];

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, index) => (
      <motion.i
        key={index}
        className={`fas fa-star ${index < rating ? 'text-yellow-400' : 'text-gray-600'}`}
        initial={{ opacity: 0, scale: 0 }}
        whileInView={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.3, delay: index * 0.1 }}
        viewport={{ once: true }}
        whileHover={{ scale: 1.2 }}
      />
    ));
  };

  return (
    <section id="testimonials" className="py-20 bg-gray-950/30">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="section-hidden">
          <motion.h2 
            className="text-4xl md:text-5xl font-bold text-center mb-16 gradient-text"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            Client Testimonials
          </motion.h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
            {testimonials.map((testimonial, index) => (
              <motion.div
                key={index}
                className={`bg-gray-900/60 rounded-xl p-6 border border-gray-800 ${testimonial.borderColor} transition-all cursor-pointer relative overflow-hidden`}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.2 }}
                viewport={{ once: true }}
                whileHover={{ 
                  y: -8, 
                  scale: 1.02,
                  boxShadow: '0 20px 40px rgba(59, 130, 246, 0.15)'
                }}
              >
                {/* Quote Icon */}
                <motion.div 
                  className="absolute top-4 right-4 text-4xl text-gray-700 opacity-20"
                  initial={{ opacity: 0, rotate: -180 }}
                  whileInView={{ opacity: 0.2, rotate: 0 }}
                  transition={{ duration: 0.6, delay: 0.3 + index * 0.2 }}
                  viewport={{ once: true }}
                >
                  <i className="fas fa-quote-right"></i>
                </motion.div>

                {/* Avatar and Info */}
                <motion.div 
                  className="flex items-center mb-4"
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.6, delay: 0.4 + index * 0.2 }}
                  viewport={{ once: true }}
                >
                  <motion.div 
                    className={`w-12 h-12 ${testimonial.bgColor} rounded-full flex items-center justify-center mr-4`}
                    whileHover={{ rotate: 360, scale: 1.1 }}
                    transition={{ duration: 0.5 }}
                  >
                    <i className={`${testimonial.avatar} text-white text-lg`}></i>
                  </motion.div>
                  <div>
                    <h4 className="font-semibold text-white">{testimonial.name}</h4>
                    <p className="text-gray-400 text-sm">{testimonial.title}</p>
                  </div>
                </motion.div>

                {/* Stars */}
                <motion.div 
                  className="flex space-x-1 mb-4"
                  initial={{ opacity: 0, y: 10 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: 0.5 + index * 0.2 }}
                  viewport={{ once: true }}
                >
                  {renderStars(testimonial.rating)}
                </motion.div>

                {/* Testimonial Text */}
                <motion.p 
                  className="text-gray-300 leading-relaxed italic"
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: 0.6 + index * 0.2 }}
                  viewport={{ once: true }}
                >
                  "{testimonial.text}"
                </motion.p>

                {/* Hover Glow Effect */}
                <motion.div 
                  className="absolute inset-0 bg-gradient-to-r from-blue-500/5 to-purple-500/5 opacity-0 transition-opacity"
                  whileHover={{ opacity: 1 }}
                />
              </motion.div>
            ))}
          </div>

          {/* Call to Action */}
          <motion.div 
            className="text-center mt-12"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.8 }}
            viewport={{ once: true }}
          >
            <motion.p 
              className="text-lg text-gray-300 mb-6"
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              transition={{ duration: 0.6, delay: 1.0 }}
              viewport={{ once: true }}
            >
              Ready to achieve similar results for your business?
            </motion.p>
            <motion.a
              href="#contact"
              className="btn-primary px-8 py-4 rounded-lg font-semibold text-white inline-flex items-center justify-center transition-all"
              whileHover={{ scale: 1.05, y: -2 }}
              whileTap={{ scale: 0.95 }}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 1.2 }}
              viewport={{ once: true }}
            >
              Let's Work Together
              <i className="fas fa-arrow-right ml-2"></i>
            </motion.a>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;