import { motion } from 'framer-motion';
import { useScrollAnimation } from '@/hooks/use-scroll-animation';
import { useEffect } from 'react';
import profileImage from '@assets/IMG-20250428-WA0019_1751253509681.jpg';

const About = () => {
  useScrollAnimation();

  const stats = [
    { number: '13+', label: 'Websites', color: 'text-blue-400', hoverColor: 'hover:border-blue-500' },
    { number: '260%', label: 'Traffic Growth', color: 'text-cyan-400', hoverColor: 'hover:border-cyan-500' },
    { number: '4+', label: 'Years Experience', color: 'text-purple-400', hoverColor: 'hover:border-purple-500' }
  ];

  return (
    <section id="about" className="py-20 relative">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="section-hidden">
          <motion.h2 
            className="text-4xl md:text-5xl font-bold text-center mb-16 gradient-text"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            About Me
          </motion.h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12 items-center">
            <motion.div 
              className="animate-fadeInLeft"
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              viewport={{ once: true }}
            >
              <div className="relative">
                <motion.div 
                  className="w-full h-96 bg-gradient-to-br from-blue-900/20 to-purple-900/20 rounded-2xl overflow-hidden border border-gray-800 hover:border-blue-500 transition-all duration-300 group"
                  whileHover={{ scale: 1.02, borderColor: '#3B82F6' }}
                  transition={{ duration: 0.3 }}
                >
                  <img 
                    src={profileImage} 
                    alt="Imran Nazir - SEO Professional & Digital Marketer"
                    className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                </motion.div>
                <motion.div 
                  className="absolute -bottom-4 -right-4 bg-gradient-to-r from-blue-500 to-purple-500 p-4 rounded-xl shadow-lg"
                  initial={{ opacity: 0, scale: 0, rotate: -180 }}
                  whileInView={{ opacity: 1, scale: 1, rotate: 0 }}
                  transition={{ duration: 0.6, delay: 0.8 }}
                  viewport={{ once: true }}
                  whileHover={{ rotate: 360, scale: 1.1 }}
                >
                  <i className="fas fa-chart-line text-2xl text-white"></i>
                </motion.div>
              </div>
            </motion.div>
            
            <motion.div 
              className="animate-fadeInRight space-y-6"
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.4 }}
              viewport={{ once: true }}
            >
              <motion.p 
                className="text-lg text-gray-300 leading-relaxed"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.6 }}
                viewport={{ once: true }}
              >
                I'm a results-driven SEO specialist and project manager with a passion for digital growth.
              </motion.p>
              
              <motion.p 
                className="text-lg text-gray-300 leading-relaxed"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.8 }}
                viewport={{ once: true }}
              >
                Over the past few years, I've worked on <span className="text-blue-400 font-semibold">13+ websites</span> across industries—starting from content writing and WordPress development to managing full-scale SEO and marketing projects.
              </motion.p>
              
              <motion.p 
                className="text-lg text-gray-300 leading-relaxed"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 1.0 }}
                viewport={{ once: true }}
              >
                I bring a <span className="text-purple-400 font-semibold">blended skillset</span> of technical knowledge (SEO, WordPress, AI tools) and creative skills (content, image design, basic video editing). Currently, I'm leading digital projects and helping brands scale organically and through paid efforts.
              </motion.p>
              
              <motion.p 
                className="text-lg text-gray-300 leading-relaxed"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 1.2 }}
                viewport={{ once: true }}
              >
                When I'm not working, I enjoy exploring AI tools, visual design, and learning emerging marketing strategies.
              </motion.p>
              
              <motion.div 
                className="mt-8 grid grid-cols-3 gap-4"
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 1.4 }}
                viewport={{ once: true }}
              >
                {stats.map((stat, index) => (
                  <motion.div
                    key={index}
                    className={`text-center p-4 bg-gray-900/50 rounded-lg border border-gray-800 ${stat.hoverColor} transition-colors cursor-pointer`}
                    whileHover={{ scale: 1.05, y: -5 }}
                    whileTap={{ scale: 0.95 }}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.6, delay: 1.6 + index * 0.1 }}
                    viewport={{ once: true }}
                  >
                    <div className={`text-2xl font-bold ${stat.color}`}>{stat.number}</div>
                    <div className="text-sm text-gray-400">{stat.label}</div>
                  </motion.div>
                ))}
              </motion.div>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
