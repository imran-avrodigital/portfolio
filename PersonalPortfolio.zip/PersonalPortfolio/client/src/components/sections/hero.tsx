import { motion } from 'framer-motion';
import { useEffect, useState } from 'react';

const Hero = () => {
  const [typingText, setTypingText] = useState('');
  const fullText = 'SEO Strategist | Content Specialist | Project Manager';

  useEffect(() => {
    let i = 0;
    const timer = setInterval(() => {
      if (i < fullText.length) {
        setTypingText(fullText.slice(0, i + 1));
        i++;
      } else {
        clearInterval(timer);
      }
    }, 100);

    return () => clearInterval(timer);
  }, []);

  const floatingElements = [
    { top: '20%', left: '10%', size: 'w-4 h-4', color: 'bg-blue-500', delay: 0 },
    { top: '30%', right: '15%', size: 'w-6 h-6', color: 'bg-purple-500', delay: 2 },
    { bottom: '25%', left: '20%', size: 'w-5 h-5', color: 'bg-cyan-500', delay: 4 }
  ];

  return (
    <section id="home" className="min-h-screen flex items-center justify-center relative overflow-hidden">
      {/* Floating Elements */}
      {floatingElements.map((element, index) => (
        <motion.div
          key={index}
          className={`floating-element absolute ${element.size} ${element.color} rounded-full opacity-20`}
          style={{
            top: element.top,
            left: element.left,
            right: element.right,
            bottom: element.bottom,
            animationDelay: `${element.delay}s`
          }}
          initial={{ opacity: 0, scale: 0 }}
          animate={{ opacity: 0.2, scale: 1 }}
          transition={{ duration: 1, delay: element.delay / 2 }}
        />
      ))}

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="space-y-8"
        >
          <motion.div 
            className="space-y-2 mb-6"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            <motion.div 
              className="text-2xl md:text-4xl font-medium text-gray-300"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.3 }}
            >
              Hello There 👋
            </motion.div>
            <motion.h1 
              className="text-4xl sm:text-5xl md:text-7xl font-bold gradient-text"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.5 }}
            >
              I'm Imran Nazir
            </motion.h1>
          </motion.div>
          
          <motion.div 
            className="text-xl md:text-2xl text-gray-300 mb-8 min-h-[2rem]"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
          >
            <span className="border-r-2 border-blue-400 pr-1 animate-pulse">
              {typingText}
            </span>
          </motion.div>
          
          <motion.div 
            className="text-lg md:text-xl text-gray-400 mb-12 max-w-3xl mx-auto"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.6 }}
          >
            I help businesses grow online through strategic SEO, content, and digital marketing. 
            Currently managing multi-channel marketing projects and leading teams across content, design, and development.
          </motion.div>
          
          <motion.div 
            className="flex flex-col sm:flex-row gap-4 justify-center"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.8 }}
          >
            <motion.a
              href="#projects"
              whileHover={{ scale: 1.05, y: -2 }}
              whileTap={{ scale: 0.95 }}
              className="btn-primary px-6 sm:px-8 py-3 sm:py-4 rounded-lg font-semibold text-white inline-flex items-center justify-center transition-all text-sm sm:text-base"
            >
              🎯 View My Work
            </motion.a>
            <motion.a
              href="#contact"
              whileHover={{ scale: 1.05, borderColor: '#3B82F6', color: '#3B82F6' }}
              whileTap={{ scale: 0.95 }}
              className="border border-gray-600 px-6 sm:px-8 py-3 sm:py-4 rounded-lg font-semibold text-white hover:shadow-lg transition-all inline-flex items-center justify-center text-sm sm:text-base"
            >
              📩 Contact Me
            </motion.a>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
};

export default Hero;
